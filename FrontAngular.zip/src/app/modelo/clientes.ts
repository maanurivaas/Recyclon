import { Cliente } from "./cliente";

export interface Clientes {
    items: Cliente[];
}
