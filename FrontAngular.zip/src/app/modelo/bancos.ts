import { Banco } from "./banco";

export interface Bancos {
    items: Banco[];
}
