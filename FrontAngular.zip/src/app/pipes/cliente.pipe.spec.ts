import { ClientePipe } from './cliente.pipe';

describe('ClientePipe', () => {
  it('create an instance', () => {
    const pipe = new ClientePipe();
    expect(pipe).toBeTruthy();
  });
});
