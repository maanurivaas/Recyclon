import { ProveedorPipe } from './proveedor.pipe';

describe('ProveedorPipe', () => {
  it('create an instance', () => {
    const pipe = new ProveedorPipe();
    expect(pipe).toBeTruthy();
  });
});
